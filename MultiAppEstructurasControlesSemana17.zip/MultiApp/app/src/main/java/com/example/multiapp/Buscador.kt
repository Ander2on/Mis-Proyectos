package com.example.multiapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient

class Buscador : AppCompatActivity() {

    var webView = findViewById<WebView>(R.id.webView)
    private val BASE_URL = "https://google.com"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_buscador)

        //webView

        webView.webChromeClient = object : WebChromeClient(){

        }

        webView.webViewClient = object : WebViewClient(){

        }

        val setting : WebSettings = webView.settings
        setting.javaScriptEnabled = true

        webView.loadUrl(BASE_URL)
    }
}