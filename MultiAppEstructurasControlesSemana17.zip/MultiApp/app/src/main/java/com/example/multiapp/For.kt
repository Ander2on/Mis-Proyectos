package com.example.multiapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView

class For : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_for)
    }


    fun tablas (view: View){
        /*
        Este apartado es para nombrartodo lo que ocuparemos en la app
         */
        var i = 1
        var t = findViewById<EditText>(R.id.txtnum).text.toString().toInt()
        var txtResultado = findViewById<TextView>(R.id.txtResultadoTablas)
        var txtResultado2 = findViewById<TextView>(R.id.txtResultadoTablas2)
        var txtResultado3 = findViewById<TextView>(R.id.txtResultadoTablas3)
        var txtResultado4 = findViewById<TextView>(R.id.txtResultadoTablas4)
        var txtResultado5 = findViewById<TextView>(R.id.txtResultadoTablas5)
        var txtResultado6 = findViewById<TextView>(R.id.txtResultadoTablas6)
        var txtResultado7 = findViewById<TextView>(R.id.txtResultadoTablas7)
        var txtResultado8 = findViewById<TextView>(R.id.txtResultadoTablas8)
        var txtResultado9 = findViewById<TextView>(R.id.txtResultadoTablas9)
        var txtResultado10 = findViewById<TextView>(R.id.txtResultadoTablas10)

        /*
        Este apartado es el que se encarga de ir mostrando en pantalla las tablas
         */
        for (i in 1..10){
            if (i == 1) {
                txtResultado.text = "${t} * ${i} = ${i * t}"
            }else if(i == 2){
                txtResultado2.text = "${t} * ${i} = ${i * t}"
            }else if(i == 3){
                txtResultado3.text = "${t} * ${i} = ${i * t}"
            }else if(i == 4){
                txtResultado4.text = "${t} * ${i} = ${i * t}"
            }else if(i == 5){
                txtResultado5.text = "${t} * ${i} = ${i * t}"
            }else if(i == 6){
                txtResultado6.text = "${t} * ${i} = ${i * t}"
            }else if(i == 7){
                txtResultado7.text = "${t} * ${i} = ${i * t}"
            }else if(i == 8){
                txtResultado8.text = "${t} * ${i} = ${i * t}"
            }else if(i == 9){
                txtResultado9.text = "${t} * ${i} = ${i * t}"
            }else if(i == 10){
                txtResultado10.text = "${t} * ${i} = ${i * t}"
            }

        }

    }

    /*
    Este apartado es para finalizar el activity
     */
    fun regresar(view: View) {
        finish()
    }
}