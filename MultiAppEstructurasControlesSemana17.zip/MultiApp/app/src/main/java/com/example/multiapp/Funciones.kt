package com.example.multiapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class Funciones : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_funciones)
    }

    /*
   Este apartado es para finalizar el activity
    */
    fun regresar(view: View) {
        finish()
    }
}