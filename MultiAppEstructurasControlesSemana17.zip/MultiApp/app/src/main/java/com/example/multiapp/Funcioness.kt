package com.example.multiapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView

data class Equipo5(val nombre:String, val url:String)

class Foreach : AppCompatActivity() {

    var primero = Equipo5("Somos","Equipo5")
    var segundo = Equipo5("Hola","Que tal?")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_funcioness)

        val boton = findViewById<Button>(R.id.btn1Funciones)
        boton.setOnClickListener {
            view -> swichEquipo5(primero)
        }
    }

    fun swichEquipo5(equipo5: Equipo5){
        when(primero.url){
            "primero" -> primero = segundo
            "segundo" -> primero = primero
            else -> print("esto no pasara")
        }
        verEnPantalla("${primero.nombre} el ${primero.url}")
    }

    fun verEnPantalla(s : String){
        val txt = findViewById<TextView>(R.id.txtFunciones)
        txt.setText(s)
    }

    /*
   Este apartado es para finalizar el activity
    */
    fun regresar(view: View) {
        finish()
    }
}