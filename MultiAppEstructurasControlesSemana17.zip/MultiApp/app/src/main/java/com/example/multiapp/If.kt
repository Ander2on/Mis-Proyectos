package com.example.multiapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView

class If : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_if)


    }

    fun calcular (view: View){
        /*
        Este apartado es para asignar los numeros y hacer la suma
         */
        val num1: Float = findViewById<EditText>(R.id.num1).text.toString().toFloat()
        val num2 = findViewById<EditText>(R.id.num2).text.toString().toFloat()
        val num3 = findViewById<EditText>(R.id.num3).text.toString().toFloat()
        var total= (num1 + num2 + num3) / 3
        //
        //txt es para mostrar el resultado
        var txtResultado = findViewById<TextView>(R.id.txtResultado)
        //

        if (total >= 6){

            txtResultado.text = "FELICIDADES USTED HA PASADO CON ${total}"

        }else {
            txtResultado.text = "LOSIENTO :( USTED A REPROBADO CON ${total}"

        }

    }


    /*
    Esta parte es para finalizar la activity y volver a la principal
     */
    fun regresar(view: View) {
        finish()
    }


}