package com.example.multiapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //Este apartado es para ir a la activity IF
        val btnif=findViewById<Button>(R.id.btnIf)
        btnif.setOnClickListener {
            val condicionnalif = Intent(this, If::class.java)
            startActivity(condicionnalif)
        }
        ////
    }

    /*
    Este es apartado es para ir a la activity WHILE
     */
    fun irWhile(view: View) {
        val irWhile = Intent(this,While::class.java)
        startActivity(irWhile)
    }

    /*
    Este apartado es para ir a la activity Foreach
     */
    fun irForeach (view: View){
        val irForeach = Intent(this,Foreach::class.java)
        startActivity(irForeach)
    }

    /*
    Este apartado es para ir a la activity When
     */
    fun irWhen (view: View){
        val irWhen = Intent(this,When::class.java)
        startActivity(irWhen)
    }

    /*
    Este apartado es para ir a la activity For
     */
    fun irFor (view: View){
        val irFor = Intent(this,For::class.java)
        startActivity(irFor)
    }

    /*
    Este aaratado es para ir a la activity Funciones
     */
    fun irFunciones(view: View){
        val irFunciones = Intent(this,Funciones::class.java)
        startActivity(irFunciones)
    }
}