package com.example.multiapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.RadioButton
import android.widget.TextView

class When : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_when)

    }

    fun verificarPais (view: View){
        /*
        Este apartado es para las variables que utilizare en el programa
         */
         var numVer:Int = findViewById<EditText>(R.id.txtNumeroPar).text.toString().toInt()
        var verResul = findViewById<TextView>(R.id.txtResultadoPar)
        var total = 0
        //
        total = (numVer % 2)//Dividimos con la funcion MOD para saber si el reciduo de la divicion es 0

        //
        //Con este When revisa si el resultado de la division es 0 y si es asi dar el mensaje que es par o viceversa
        when (total){
            0 -> {
                verResul.text = "ESTE NUMERO ES PAR "
            }
            else ->{
                verResul.text = "ESTE NUMERO ES IMPAR"
            }
        }
    }

    /*
   Este apartado es para finalizar el activity
    */
    fun regresar(view: View) {
        finish()
    }
}