package com.example.multiapp

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class While : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_while)
    }

    /*
    Esta parte es para el boton de calcular la suma
     */
    fun btnCalcularSuma (view: View){
        /*
        Todas estas variables son las que utiliza la app para tomar los numeros comvertirlos y dar en pantalla
         */
        var txt1:String = findViewById<EditText>(R.id.num1While).text.toString()
        var txt2:String = findViewById<EditText>(R.id.num2While).text.toString()
        var txt1While = findViewById<TextView>(R.id.txt1While)
        var txt2While = findViewById<TextView>(R.id.txt2While)
        var tex = findViewById<TextView>(R.id.textView)
        var tex2 = findViewById<TextView>(R.id.textView2While)

        /*
           Todas estas variables son para los numeros y la suma
        */
        var num1:Double = findViewById<EditText>(R.id.num1While).text.toString().toDouble()
        var num2:Double = findViewById<EditText>(R.id.num2While).text.toString().toDouble()
        var txtrespuesta: Double = findViewById<EditText>(R.id.txtRespuestaWhile).text.toString().toDouble()
        var total = num1 + num2

        //Esto es para asignarle el tex a los texview
        txt1While.text = txt1
        txt2While.text = txt2


        var i =1 //Esta variable es la que ayudara a decirle al while cunatas veces debe de correr antes de salir de la ejecucion del while
        while (i < 2 ){
            /*
            Este if sirve para comprobar si la respuesta introducida es la respuesta correcta de la suma
             */
            if (txtrespuesta == total) {
                tex2.setVisibility(View.INVISIBLE)
                tex.setVisibility(View.VISIBLE)
                tex.text = "LA RESPUESTA ES CORRECTA 😎"
            }else {
                tex2.setVisibility(View.VISIBLE)
                tex.setVisibility(View.INVISIBLE)
                tex2.text = "LA RESPUESTA ES INCORRECTA 😢"
            }

            i++ //Este esta sumando +1 a la variable i para que pueda salir del bucle
        }


    }


    fun visible (view: View){
        var txt1= findViewById<EditText>(R.id.num1While)
        var txt2= findViewById<EditText>(R.id.num2While)
        val btnASumar = findViewById<Button>(R.id.btnCalcularSuma2)
        val btnCalcularSumar = findViewById<Button>(R.id.btnCalcularSuma)
        val txtvisible1 = findViewById<TextView>(R.id.txt1While)
        val txtvisible2 = findViewById<TextView>(R.id.txt2While)
        val txtrespuesta = findViewById<TextView>(R.id.txtRespuestaWhile)
        val txtlinea= findViewById<TextView>(R.id.editTextTextPersonName)

        txtvisible1.text =txt1.text
        txtvisible2.text =txt2.text


        btnASumar.setVisibility(View.INVISIBLE)
        txt1.setVisibility(View.INVISIBLE)
        txt2.setVisibility(View.INVISIBLE)
        btnCalcularSumar.setVisibility(View.VISIBLE)
        txtvisible1.setVisibility(View.VISIBLE)
        txtvisible2.setVisibility(View.VISIBLE)
        txtrespuesta.setVisibility(View.VISIBLE)
        txtlinea.setVisibility(View.VISIBLE)


    }



    /*
   Este apartado es para finalizar el activity
    */
    fun regresar(view: View) {
        finish()
    }
}