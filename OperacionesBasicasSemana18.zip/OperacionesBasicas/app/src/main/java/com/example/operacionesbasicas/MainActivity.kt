package com.example.operacionesbasicas

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
     fun irOper (view: View){
         val irOper = Intent (this, OperacionesBasicas::class.java)
         startActivity(irOper)
     }

    fun irAcerca(view: View) {
        val irAcerca = Intent(this,AcercaDe::class.java)
        startActivity(irAcerca)
    }
}