package com.example.operacionesbasicas

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView

class OperacionesBasicas : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_operaciones_basicas)

    }

    fun Numeros (view: View){
        var num1:Double = findViewById<EditText>(R.id.txtnum1).text.toString().toDouble()
        var num2:Double = findViewById<EditText>(R.id.txtnum2).text.toString().toDouble()
        var total = 0.0
        var txtre = findViewById<TextView>(R.id.txtRespuesta)
        var txtsim = findViewById<TextView>(R.id.txtSimbolo)

    }

    fun regresar(view: View) {
        finish()
    }

    fun sumar(view: View) {
        var num1:Double = findViewById<EditText>(R.id.txtnum1).text.toString().toDouble()
        var num2:Double = findViewById<EditText>(R.id.txtnum2).text.toString().toDouble()
        var total = num1 + num2
        var txtre = findViewById<TextView>(R.id.txtRespuesta)
        var txtsim = findViewById<TextView>(R.id.txtSimbolo)

        txtre.text = "${total}"
        txtsim.text = "+"
    }

    fun dividir(view: View) {
        var num1:Double = findViewById<EditText>(R.id.txtnum1).text.toString().toDouble()
        var num2:Double = findViewById<EditText>(R.id.txtnum2).text.toString().toDouble()
        var total = num1 / num2
        var txtre = findViewById<TextView>(R.id.txtRespuesta)
        var txtsim = findViewById<TextView>(R.id.txtSimbolo)

        txtre.text = "${total}"
        txtsim.text = "%"
    }

    fun multiplicacion(view: View) {
        var num1:Double = findViewById<EditText>(R.id.txtnum1).text.toString().toDouble()
        var num2:Double = findViewById<EditText>(R.id.txtnum2).text.toString().toDouble()
        var total = num1 * num2
        var txtre = findViewById<TextView>(R.id.txtRespuesta)
        var txtsim = findViewById<TextView>(R.id.txtSimbolo)

        txtre.text = "${total}"
        txtsim.text = "*"
    }

    fun resta(view: View) {
        var num1:Double = findViewById<EditText>(R.id.txtnum1).text.toString().toDouble()
        var num2:Double = findViewById<EditText>(R.id.txtnum2).text.toString().toDouble()
        var total = num1 - num2
        var txtre = findViewById<TextView>(R.id.txtRespuesta)
        var txtsim = findViewById<TextView>(R.id.txtSimbolo)

        txtre.text = "${total}"
        txtsim.text = "-"
    }
}