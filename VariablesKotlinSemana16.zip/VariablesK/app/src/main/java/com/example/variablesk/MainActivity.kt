package com.example.variablesk

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    //Esta es la variable de tipo "var" ya que sera modificada para dar el resultado
    var total: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

    }

    /*
    Este apartado lo utilizamos para el Boton sumar de 1 en 1
     */
    fun sumar(view: View) {

        total = total + 1

        var resultado: String = (total).toString()

        var txtcontador = findViewById<TextView>(R.id.txtcontador)
        txtcontador.setText(resultado)

    }

    /*
    Este apartado lo utilizamos para el boton restar de 1 en 1
     */
    fun restar(view: View) {

        total = total - 1

        var resul: String = (total).toString()

        var txtcontador = findViewById<TextView>(R.id.txtcontador)
        txtcontador.setText(resul)
    }

    /*
    Este apartado lo usamos para el boton sumar de 2 en 2
     */
    fun sumar2(view: View){
        total = total +2

        var respuestasuma:String = (total).toString()
        var resultadoSuma = findViewById<TextView>(R.id.txtcontador)

        resultadoSuma.setText(respuestasuma)

    }

    /*
    Este apartado lo utilizamos para la resta de 2 en 2
     */
    fun restar2(view: View){
        total = total - 2

        var resultadoresta:String = (total).toString()
         var txtcontador = findViewById<TextView>(R.id.txtcontador)
        txtcontador.setText(resultadoresta)
    }
}

